"use client";

function CompanyInfoPage() {
  return <div className="p-6">Company Info Page</div>;
}

export default CompanyInfoPage;
