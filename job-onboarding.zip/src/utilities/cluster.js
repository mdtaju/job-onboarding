const cluster = [
  {
    type: "Feature",
    properties: {
      cluster: false,
      crimeId: 78212911,
      category: "anti-social-behaviour",
    },
    geometry: { type: "Point", coordinates: [-1.135171, 52.6376] },
  },
];

export default cluster;
