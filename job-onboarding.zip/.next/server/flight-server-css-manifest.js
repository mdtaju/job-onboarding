self.__RSC_CSS_MANIFEST={
  "cssImports": {
    "C:\\Users\\Sohan Computer\\Desktop\\React-Apps\\job-onboarding\\app\\page.js": [
      "C:\\Users\\Sohan Computer\\Desktop\\React-Apps\\job-onboarding\\node_modules\\maplibre-gl\\dist\\maplibre-gl.css"
    ],
    "C:\\Users\\Sohan Computer\\Desktop\\React-Apps\\job-onboarding\\app\\layout.js": [
      "C:\\Users\\Sohan Computer\\Desktop\\React-Apps\\job-onboarding\\node_modules\\maplibre-gl\\dist\\maplibre-gl.css",
      "C:\\Users\\Sohan Computer\\Desktop\\React-Apps\\job-onboarding\\app\\globals.css"
    ]
  },
  "cssModules": {
    "C:\\Users\\Sohan Computer\\Desktop\\React-Apps\\job-onboarding\\app\\page": [
      "C:\\Users\\Sohan Computer\\Desktop\\React-Apps\\job-onboarding\\node_modules\\maplibre-gl\\dist\\maplibre-gl.css",
      "C:\\Users\\Sohan Computer\\Desktop\\React-Apps\\job-onboarding\\app\\globals.css"
    ],
    "C:\\Users\\Sohan Computer\\Desktop\\React-Apps\\job-onboarding\\app\\job\\page": [
      "C:\\Users\\Sohan Computer\\Desktop\\React-Apps\\job-onboarding\\node_modules\\maplibre-gl\\dist\\maplibre-gl.css",
      "C:\\Users\\Sohan Computer\\Desktop\\React-Apps\\job-onboarding\\app\\globals.css"
    ]
  }
}